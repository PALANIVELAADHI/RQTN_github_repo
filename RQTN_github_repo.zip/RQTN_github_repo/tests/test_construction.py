"""Sanity tests: group axioms, CSS commutation, rate lower bound, logical count."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "study"))
import numpy as np
from common import group, make_code, generates


def test_group_axioms():
    G = group(5)
    assert G.order == 60
    rng = np.random.default_rng(0)
    for _ in range(200):
        a, b, c = rng.integers(G.order, size=3)
        assert G.mul[G.mul[a, b], c] == G.mul[a, G.mul[b, c]]
        assert G.mul[a, G.inv[a]] == G.identity


def test_orders():
    assert group(5).order == 60 and group(7).order == 168


def test_css_commutation_and_rate_bound():
    Q = make_code(5, 8, 5, 3, seed=8)
    assert Q.n == 60 * 8 * 8 // 2
    assert Q.commutes()
    par = Q.parameters()
    bound = 60 * (8 * 8 / 2 - 5 * 3 - 3 * 5)
    assert par["k"] >= bound
    Lx, Lz = Q.logicals()
    assert Lx.shape[0] == Lz.shape[0] == par["k"]


def test_generation():
    Q = make_code(5, 8, 5, 3, seed=8)
    assert generates(Q.G, Q.A) and generates(Q.G, Q.B)


def test_bipartite_variant_commutes():
    from common import random_AB_bip, best_local_code
    from qtanner.groups import PGL2
    from qtanner.complex_bip import QuantumTannerBipartite
    G = PGL2(5)
    assert G.order == 120 and int(G.odd.sum()) == 60
    rng = np.random.default_rng(3)
    A, B = random_AB_bip(G, 6, rng)
    Q = QuantumTannerBipartite(G, A, B, best_local_code(6, 4, rng), best_local_code(6, 2, rng))
    assert Q.n == 60 * 6 * 6 // 2 and Q.commutes()
    assert Q.parameters()["k"] >= 60 * (6 * 6 / 2 - 4 * 2 - 2 * 4)
