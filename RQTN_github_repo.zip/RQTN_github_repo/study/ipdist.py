"""Integer-programming helper: minimum weight of a logical operator in one logical class."""
import numpy as np, scipy.sparse as sp
from scipy.optimize import milp, LinearConstraint, Bounds


def solve_class(Hs, lrow, tl=8.0):
    """min |x| s.t. Hs x = 0 (mod 2) and lrow.x = 1 (mod 2); returns dict(ub, lb, status)."""
    Hs = sp.csr_matrix(Hs); n = Hs.shape[1]; m = Hs.shape[0]
    A = sp.vstack([sp.hstack([Hs, -2 * sp.identity(m)]),
                   sp.hstack([sp.csr_matrix(lrow.reshape(1, -1)), sp.csr_matrix((1, m))])]).tocsr().astype(float)
    A = sp.hstack([A, sp.csr_matrix(([-2.0], ([m], [0])), shape=(m + 1, 1))]).tocsr()
    lb = np.concatenate([np.zeros(m), [1.0]])
    c = np.concatenate([np.ones(n), np.zeros(m + 1)])
    bounds = Bounds(np.zeros(n + m + 1), np.concatenate([np.ones(n), np.full(m + 1, 40.0)]))
    r = milp(c, constraints=LinearConstraint(A, lb, lb.copy()), integrality=np.ones(n + m + 1),
             bounds=bounds, options={"time_limit": tl, "disp": False})
    return dict(status=int(r.status), ub=(float(r.fun) if r.fun is not None else None),
                lb=(float(r.mip_dual_bound) if getattr(r, "mip_dual_bound", None) is not None else None))


def ip_bounds(Q, Lx, Lz, per_type, tl, rng):
    """Sample per_type logical classes per Pauli type; return best X and Z upper bounds."""
    out = {"X": [], "Z": []}
    for typ, Hs, Ld in (("X", Q.Hz, Lz), ("Z", Q.Hx, Lx)):
        js = rng.choice(Ld.shape[0], min(per_type, Ld.shape[0]), replace=False)
        for j in js:
            r = solve_class(Hs, Ld[j].toarray().ravel(), tl); r["j"] = int(j); out[typ].append(r)
    return out


def best(out, typ):
    v = [r["ub"] for r in out[typ] if r["ub"] is not None]
    return min(v) if v else None
