#!/bin/bash
cd "$(dirname "$0")"
python3 s2_ler.py >> ../data/run_s2.log 2>&1
echo ALLDONE >> ../data/run_s2.log
