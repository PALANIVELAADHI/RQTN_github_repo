"""Extra decoders and generic Monte-Carlo runner used by the network study."""
import time
import numpy as np
import scipy.sparse as sp


def greedy_decode(Ht, s, max_iter=5000):
    """Syndrome-based greedy bit-flip: repeatedly flip the qubit that most reduces the syndrome weight.
    Ht = H^T as CSR (n x m)."""
    u = s.astype(np.int64).copy(); e = np.zeros(Ht.shape[0], dtype=np.uint8)
    for _ in range(max_iter):
        if not u.any():
            break
        gains = Ht @ (2 * u - 1)
        j = int(np.argmax(gains))
        if gains[j] <= 0:
            break
        e[j] ^= 1
        col = Ht.indices[Ht.indptr[j]:Ht.indptr[j + 1]]
        u[col] ^= 1
    return e


def run_generic(Hdet, Ldet, p, shots, rng, decode, batch=None):
    """decode(syndrome)->correction (single) ; returns dict with failures, seconds/shot."""
    n = Hdet.shape[1]; fails = 0; t_dec = 0.0
    for _ in range(shots):
        e = (rng.random(n) < p).astype(np.uint8)
        s = (Hdet @ e) % 2
        t0 = time.perf_counter(); c = np.asarray(decode(s), dtype=np.uint8); t_dec += time.perf_counter() - t0
        r = e ^ c
        if ((Hdet @ r) % 2).any() or ((Ldet @ r) % 2).any():
            fails += 1
    return dict(p=p, shots=shots, fails=fails, sec_per_shot=t_dec / shots)
