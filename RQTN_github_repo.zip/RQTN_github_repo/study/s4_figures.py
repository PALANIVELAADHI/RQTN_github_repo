"""S4: all figures of the paper (diagrams + 9 result figures) from data/*.json."""
import os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Polygon, Rectangle, Circle
D = os.path.join(os.path.dirname(__file__), "..", "data"); F = os.path.join(os.path.dirname(__file__), "..", "figures")
ld = lambda n: json.load(open(os.path.join(D, n)))
plt.rcParams.update({"font.size": 8, "font.family": "DejaVu Sans", "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.alpha": .25, "legend.fontsize": 7, "axes.titlesize": 8.5})
BL, RD, GR, OR, PU, GY = "#2b6cb0", "#c53030", "#2f855a", "#dd6b20", "#6b46c1", "#718096"
save = lambda fig, n: (fig.tight_layout(), fig.savefig(os.path.join(F, n), dpi=300, bbox_inches="tight"), plt.close(fig))
def box(ax, x, y, w, h, t, fc="#edf2f7", fs=7, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.06", fc=fc, ec="#2d3748", lw=1)); ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=fs, fontweight="bold" if bold else "normal")
def arr(ax, p, q, c="#2d3748"): ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=9, lw=1.1, color=c))

# ===================== DIAGRAMS =====================
# D1 architecture
fig, ax = plt.subplots(figsize=(7.1, 4.3)); ax.set_xlim(0, 10); ax.set_ylim(0, 6.2); ax.axis("off")
ax.text(0.05, 5.95, "A. Code construction layer", fontsize=8, fontweight="bold", color=BL)
box(ax, 0.1, 4.95, 1.9, .8, "Group G\nPSL(2,q) / PGL(2,q)\n(mult. table)", "#ebf8ff"); box(ax, 2.3, 4.95, 2.1, .8, "Generating sets A, B\nsymmetric, generate G,\ndisjoint conj. classes", "#ebf8ff")
box(ax, 4.7, 4.95, 2.3, .8, "Left-right Cayley complex\nV0, V1; squares = qubits", "#ebf8ff"); box(ax, 7.3, 4.95, 2.5, .8, "Local codes C_A, C_B\n(tensor-code checks at vertices)", "#ebf8ff")
arr(ax, (2.0, 5.35), (2.3, 5.35)); arr(ax, (4.4, 5.35), (4.7, 5.35)); arr(ax, (7.3, 5.35), (7.0, 5.35))
ax.text(0.05, 4.55, "B. Code analysis layer", fontsize=8, fontweight="bold", color=GR)
box(ax, 0.1, 3.5, 2.3, .8, "CSS matrices HX, HZ\nHX HZ^T = 0 (mod 2) check", "#f0fff4"); box(ax, 2.7, 3.5, 2.3, .8, "n, k, rate (GF(2) ranks)\ncheck weights", "#f0fff4")
box(ax, 5.3, 3.5, 2.2, .8, "Spectral diagnostics\nDelta_spec; Cayley ratio rho", "#f0fff4"); box(ax, 7.8, 3.5, 2.0, .8, "Logical weights\ngreedy + integer program", "#f0fff4")
arr(ax, (5.9, 4.95), (1.3, 4.3)); arr(ax, (2.4, 3.9), (2.7, 3.9)); arr(ax, (5.0, 3.9), (5.3, 3.9)); arr(ax, (7.5, 3.9), (7.8, 3.9))
ax.text(0.05, 3.1, "C. Noise, decoding and network layer", fontsize=8, fontweight="bold", color=OR)
box(ax, 0.1, 2.0, 1.9, .8, "Physical noise p\n(code capacity)", "#fffaf0"); box(ax, 2.3, 2.0, 2.0, .8, "Syndrome s = H e\n(mod 2)", "#fffaf0"); box(ax, 4.6, 2.0, 2.4, .8, "Decoders: greedy,\nBP+OSD-0, MWPM (toric)", "#fffaf0"); box(ax, 7.3, 2.0, 2.5, .8, "Logical failure test\nP_L, fidelity F_L", "#fffaf0")
for a, b in ((2.0, 2.3), (4.3, 4.6), (7.0, 7.3)): arr(ax, (a, 2.4), (b, 2.4))
arr(ax, (1.3, 3.5), (1.3, 2.8), GY)
box(ax, 0.1, 0.8, 2.4, .8, "Lossy links: eta(D) = 10^(-alpha D/10)\nP_end = prod P_succ,i", "#faf5ff"); box(ax, 2.8, 0.8, 2.3, .8, "Latency T_lat = T_prop + T_op\n+ T_syn + T_dec", "#faf5ff")
box(ax, 5.4, 0.8, 2.1, .8, "Throughput\nTheta = P_end (1-P_L)/T_lat", "#faf5ff"); box(ax, 7.8, 0.8, 2.0, .8, "Resource cost\nC_phys = N_code+N_anc+N_net", "#faf5ff")
arr(ax, (8.5, 2.0), (6.4, 1.6)); arr(ax, (2.5, 1.2), (2.8, 1.2)); arr(ax, (5.1, 1.2), (5.4, 1.2)); arr(ax, (7.5, 1.2), (7.8, 1.2)); arr(ax, (3.5, 2.0), (3.9, 1.6), GY)
ax.text(5, 0.25, "Identical channel, decoder and accounting are applied to the toric control and to the Cayley/Tanner family.", ha="center", fontsize=7.5, style="italic", color=GY)
save(fig, "fig_d1_architecture.png")
# D2 network chain model
fig, ax = plt.subplots(figsize=(7.1, 2.2)); ax.set_xlim(0, 12); ax.set_ylim(0, 3); ax.axis("off")
xs = [0.9, 3.4, 5.9, 8.4, 10.9]
for i, x in enumerate(xs):
    ax.add_patch(Circle((x, 1.7), .42, fc="#bee3f8" if i in (0, len(xs) - 1) else "#e2e8f0", ec="k")); ax.text(x, 1.7, "A" if i == 0 else "B" if i == len(xs) - 1 else f"R{i}", ha="center", va="center", fontsize=8, fontweight="bold")
    if i: arr(ax, (xs[i - 1] + .45, 1.7), (x - .45, 1.7), BL); ax.text((xs[i - 1] + x) / 2, 2.05, f"link {i}: eta, 1-p", ha="center", fontsize=7)
box(ax, 0.3, 0.1, 2.3, .75, "Encoded block (n,k)\nsyndrome + decode at node", "#f0fff4", 6.5); box(ax, 3.1, 0.1, 3.0, .75, "P_end = prod_i eta(D_i)(1-p)", "#faf5ff", 7); box(ax, 6.6, 0.1, 2.5, .75, "T_lat = T_prop+T_op+T_syn+T_dec", "#fffaf0", 6.5); box(ax, 9.5, 0.1, 2.2, .75, "Theta = P_end(1-P_L)/T_lat", "#faf5ff", 6.5)
save(fig, "fig_d2_network_model.png")
# D3 workflow flowchart
fig, ax = plt.subplots(figsize=(3.45, 5.2)); ax.set_xlim(0, 6); ax.set_ylim(0, 10); ax.axis("off")
steps = ["Group G, generators A, B,\nlocal codes C_A, C_B", "Build squares, local views,\nHX, HZ", "Test HX HZ^T = 0 (mod 2)", "Ranks (GF(2)): n, k, R;\ncheck weights", "Delta_spec, rho(A), rho(B)", "Logical weights:\ngreedy + integer program", "Sample error e ~ Bernoulli(p);\ns = H e (mod 2)", "Decode (greedy / BP+OSD-0 /\nMWPM); residual test", "Estimate P_L (Wilson CI),\nF_L, decoder time", "Network layer: P_end, T_lat,\nTheta, C_phys; export CSV/JSON"]
ys = np.linspace(9.2, 0.4, len(steps))
for i, (t, y) in enumerate(zip(steps, ys)):
    if i == 2:
        ax.add_patch(Polygon([[3, y + .45], [5.2, y], [3, y - .45], [.8, y]], fc="#fefcbf", ec="k")); ax.text(3, y, t, ha="center", va="center", fontsize=6.3)
    else: box(ax, 0.6, y - .33, 4.8, .66, t, "#edf2f7", 6.3)
    if i: arr(ax, (3, ys[i - 1] - (.45 if i - 1 == 2 else .33)), (3, y + (.45 if i == 2 else .33)))
ax.text(5.6, ys[2] + .05, "no: reject", fontsize=6, color=RD, ha="right")
save(fig, "fig_d3_workflow.png")

# ===================== RESULT FIGURES =====================
par = ld("params.json"); ler = ld("ler.json"); net = ld("network.json") if os.path.exists(os.path.join(D, "network.json")) else None
tor = par["toric"]; sel = par["tanner_selected"]; uns = par["tanner_unselected"]
TC = {"Toric L=23": BL, "Toric L=31": "#63b3ed", "QT-1080": RD, "QT-1920": OR, "QT-3024": PU}
def pts(code, dec): 
    r = sorted(ler[code]["dec"][dec], key=lambda x: x["p"]); return np.array([x["p"] for x in r]), np.array([x["ler"] for x in r]), np.array([x["lo"] for x in r]), np.array([x["hi"] for x in r]), np.array([x["fails"] for x in r]), np.array([x["shots"] for x in r])
# R1 parameters
fig, ax = plt.subplots(1, 3, figsize=(7.1, 2.5))
ax[0].plot([r["n"] for r in tor], [r["k"] for r in tor], "s-", color=BL, ms=3, label="toric (control)"); ax[0].scatter([r["n"] for r in uns], [r["k"] for r in uns], s=10, color=GY, label="Tanner, unselected"); ax[0].scatter([r["n"] for r in sel], [r["k"] for r in sel], s=26, color=RD, zorder=3, label="Tanner, selected")
ax[0].set_xscale("log"); ax[0].set_yscale("log"); ax[0].set_xlabel("block length n"); ax[0].set_ylabel("logical qubits k"); ax[0].set_title("(a) encoded qubits"); ax[0].legend(frameon=False)
ax[1].plot([r["n"] for r in tor], [r["rate"] for r in tor], "s-", color=BL, ms=3); ax[1].scatter([r["n"] for r in uns], [r["rate"] for r in uns], s=10, color=GY); ax[1].scatter([r["n"] for r in sel], [r["rate"] for r in sel], s=26, color=RD, zorder=3)
ax[1].set_xscale("log"); ax[1].set_yscale("log"); ax[1].set_xlabel("block length n"); ax[1].set_ylabel("rate R = k/n"); ax[1].set_title("(b) code rate")
names = ["Toric L=23"] + [r["name"] for r in sel]; rowv = [[r for r in tor if r["L"] == 23][0]["row_wt"]] + [r["row_wt"] for r in sel]; colv = [[r for r in tor if r["L"] == 23][0]["col_wt"]] + [r["col_wt"] for r in sel]
x = np.arange(len(names)); ax[2].bar(x - .2, rowv, .4, color=BL, label="max check weight"); ax[2].bar(x + .2, colv, .4, color=OR, label="max qubit degree"); ax[2].set_xticks(x); ax[2].set_xticklabels([n.replace("Toric ", "Toric\n") for n in names], fontsize=6.5); ax[2].set_ylabel("weight"); ax[2].set_title("(c) sparsity"); ax[2].legend(frameon=False)
save(fig, "fig_r1_parameters.png")
# R2 spectral
fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.6))
ax[0].plot([r["n"] for r in tor], [r["delta_spec"] for r in tor], "s-", color=BL, ms=3, label="toric"); ax[0].scatter([r["n"] for r in uns], [r["delta_spec"] for r in uns], s=10, color=GY, label="Tanner, unselected"); ax[0].scatter([r["n"] for r in sel], [r["delta_spec"] for r in sel], s=26, color=RD, zorder=3, label="Tanner, selected")
ax[0].set_xscale("log"); ax[0].set_yscale("log"); ax[0].set_xlabel("block length n"); ax[0].set_ylabel(r"$\Delta_{\rm spec}=\lambda^+_{\min}(H_X^TH_X+H_Z^TH_Z)$"); ax[0].set_title("(a) smallest nonzero eigenvalue of the check Laplacian"); ax[0].legend(frameon=False)
allr = [(r["name"], max(r["rhoA"], r["rhoB"]), RD) for r in sel] + [(r["name"], max(r["rhoA"], r["rhoB"]), GY) for r in uns]
ax[1].bar(range(len(allr)), [a[1] for a in allr], color=[a[2] for a in allr]); ax[1].axhline(1, color="k", ls="--", lw=1); ax[1].set_xticks(range(len(allr))); ax[1].set_xticklabels([a[0] for a in allr], rotation=90, fontsize=5.5)
ax[1].set_ylabel(r"$\rho=\max(\lambda_A,\lambda_B)/(2\sqrt{\Delta-1})$"); ax[1].set_title("(b) Cayley-graph spectral ratio (Ramanujan if $\\rho\\leq1$)")
save(fig, "fig_r2_spectral.png")
# R3 logical weights
e15 = ld("prior_e15_ip_unselected.json")
fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.7))
ax[0].plot([r["n"] for r in tor], [r["d"] for r in tor], "s-", color=BL, ms=3, label="toric: exact d = L")
ax[0].scatter([r["n"] for r in sel], [r["d_best"] for r in sel], s=30, color=RD, zorder=3, label="Tanner selected: best-found (IP), upper bound")
ax[0].scatter([r["n"] for r in sel], [min(r["greedy"]) for r in sel], s=30, facecolors="none", edgecolors=RD, zorder=3, label="Tanner selected: greedy bound (all classes)")
un = [(r["n"], min(x for x in (r["ipX"], r["ipZ"]) if x is not None)) for r in e15 if (r["ipX"] is not None or r["ipZ"] is not None)]
ax[0].scatter([a for a, _ in un], [b for _, b in un], s=10, color=GY, label="Tanner unselected: best-found (IP, sampled classes)")
ax[0].set_xscale("log"); ax[0].set_yscale("log"); ax[0].set_xlabel("block length n"); ax[0].set_ylabel("logical weight (distance bound)"); ax[0].set_title("(a) distance versus block length"); ax[0].legend(frameon=False, fontsize=5.8)
ax[1].plot([r["n"] for r in tor], [r["d"] / r["n"] for r in tor], "s-", color=BL, ms=3, label="toric d/n"); ax[1].scatter([r["n"] for r in sel], [r["d_best"] / r["n"] for r in sel], s=30, color=RD, label="Tanner selected (upper bound)", zorder=3)
ax[1].scatter([a for a, _ in un], [b / a for a, b in un], s=10, color=GY, label="Tanner unselected (upper bound)")
ax[1].set_xscale("log"); ax[1].set_yscale("log"); ax[1].set_xlabel("block length n"); ax[1].set_ylabel("d / n"); ax[1].set_title("(b) normalized distance"); ax[1].legend(frameon=False, fontsize=6)
save(fig, "fig_r3_distance.png")
# R4 LER matched
def series(a, code, dec, c, lab, ls="-", mk="o", norm=1.0):
    p, l, lo, hi, f, s = pts(code, dec); nz = f > 0
    if nz.any(): a.errorbar(p[nz], l[nz] / norm, yerr=[(l[nz] - lo[nz]) / norm, (hi[nz] - l[nz]) / norm], fmt=mk + ls, ms=3, color=c, capsize=1.5, lw=1, label=lab)
    else: a.plot([], [], mk + ls, color=c, ms=3, label=lab)
    if (~nz).any(): a.plot(p[~nz], hi[~nz] / norm, "v", color=c, ms=4, mfc="none", mew=.8)
fig, ax = plt.subplots(1, 3, figsize=(7.1, 2.7), sharex=True)
for a, (tc, qc) in zip(ax[:2], (("Toric L=23", "QT-1080"), ("Toric L=31", "QT-1920"))):
    series(a, tc, "mwpm", BL, f"{tc} MWPM", "--", "s"); series(a, tc, "bp_osd0", "#63b3ed", f"{tc} BP+OSD-0", "-", "^"); series(a, qc, "bp_osd0", RD, f"{qc} BP+OSD-0")
    a.set_xscale("log"); a.set_yscale("log"); a.set_xlabel("physical error probability p"); a.legend(frameon=False, fontsize=5.8, loc="upper left")
ax[0].set_ylabel(r"block logical error $P_{\rm L}$"); ax[0].set_title("(a) n=1058 vs n=1080"); ax[1].set_title("(b) n=1922 vs n=1920")
for tc, c in (("Toric L=23", BL), ("Toric L=31", "#63b3ed")): series(ax[2], tc, "mwpm", c, f"{tc} MWPM (k=2)", "--", "s", norm=2)
for qc in ("QT-1080", "QT-1920", "QT-3024"): series(ax[2], qc, "bp_osd0", TC[qc], f"{qc} (k={ler[qc]['k']})", "-", "o", norm=ler[qc]["k"])
ax[2].set_xscale("log"); ax[2].set_yscale("log"); ax[2].set_xlabel("physical error probability p"); ax[2].set_ylabel("$P_{\\rm L}/k$ (normalized)"); ax[2].set_title("(c) per logical qubit"); ax[2].legend(frameon=False, fontsize=5.4, loc="upper left")
fig.text(0.5, -0.02, "Open triangles (down): 95% Wilson upper limit when zero failures were observed.", ha="center", fontsize=6.5, style="italic")
save(fig, "fig_r4_logical_error.png")
# R5 fidelity
fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.5))
for code in ("Toric L=23", "Toric L=31", "QT-1080", "QT-1920", "QT-3024"):
    p, l, lo, hi, f, s = pts(code, "bp_osd0"); k = ler[code]["k"]
    ax[0].plot(p, 1 - l, "o-", ms=3, color=TC[code], label=code); ax[1].plot(p, 1 - l / k, "o-", ms=3, color=TC[code], label=code)
for a in ax: a.set_xscale("log"); a.set_xlabel("physical error probability p")
ax[0].set_ylabel(r"block fidelity $F_{\rm L}=1-P_{\rm L}$"); ax[0].set_title("(a) all-logical-qubits-correct fidelity"); ax[1].set_ylabel(r"$1-P_{\rm L}/k$"); ax[1].set_title("(b) per-logical-qubit normalization"); ax[0].legend(frameon=False, fontsize=6)
save(fig, "fig_r5_fidelity.png")
# R6 decoders
fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.7))
order = [("Toric L=23", ["greedy", "bp_osd0", "mwpm"]), ("QT-1080", ["greedy", "bp_osd0"]), ("Toric L=31", ["greedy", "bp_osd0", "mwpm"]), ("QT-1920", ["greedy", "bp_osd0"]), ("QT-3024", ["greedy", "bp_osd0"])]
DC = {"greedy": GY, "bp_osd0": RD, "mwpm": BL}; DL = {"greedy": "greedy", "bp_osd0": "BP+OSD-0", "mwpm": "MWPM"}
for panel, pp, key in ((0, 0.005, "ler"), (1, 0.01, "t")):
    a = ax[panel]; x0 = 0
    for ci, (code, decs) in enumerate(order):
        for di, dec in enumerate(decs):
            r = [q for q in ler[code]["dec"][dec] if abs(q["p"] - pp) < 1e-12][0]
            v = r["ler"] if key == "ler" else r["sec_per_shot"] * 1e3
            if key == "ler" and r["fails"] == 0: v = r["hi"]
            a.bar(ci + (di - (len(decs) - 1) / 2) * .26, v, .24, color=DC[dec], label=DL[dec] if ci == 0 or (ci == 2 and dec == "mwpm") else None, hatch="//" if (key == "ler" and r["fails"] == 0) else None)
    a.set_yscale("log"); a.set_xticks(range(len(order))); a.set_xticklabels([o[0].replace("Toric ", "Toric\n") for o in order], fontsize=6.5)
ax[0].set_ylabel(r"block logical error $P_{\rm L}$ at $p=0.005$"); ax[0].set_title("(a) decoders (hatched: 0 failures; bar = 95% upper limit)"); ax[1].set_ylabel("decoding time per shot (ms), p=0.01"); ax[1].set_title("(b) software decoding time"); ax[0].legend(frameon=False, fontsize=6)
save(fig, "fig_r6_decoders.png")
# R7 latency / throughput
if net:
    C = net["codes"]; keys = [k for k in ("Toric L=23 [mwpm]", "Toric L=23 [bp_osd0]", "QT-1080 [bp_osd0]", "Toric L=31 [mwpm]", "QT-1920 [bp_osd0]", "QT-3024 [bp_osd0]") if k in C]
    SHORT = {"Toric L=23 [mwpm]": "T23\nMWPM", "Toric L=23 [bp_osd0]": "T23\nBP+OSD", "QT-1080 [bp_osd0]": "QT\n1080", "Toric L=31 [mwpm]": "T31\nMWPM", "QT-1920 [bp_osd0]": "QT\n1920", "QT-3024 [bp_osd0]": "QT\n3024"}
    colr = {k: (BL if "Toric L=23" in k else "#63b3ed" if "Toric L=31" in k else TC[k.split(" [")[0]]) for k in keys}
    fig, ax = plt.subplots(1, 3, figsize=(7.1, 2.7))
    x = np.arange(len(keys)); N4 = 3
    for sc, off, hat in (("software (measured CPU)", -.2, None), ("dedicated hardware (assumed 10 us)", .2, "//")):
        ax[0].bar(x + off, [[r for r in C[k]["rows"] if r["scen"] == sc][N4]["T_lat"] * 1e3 for k in keys], .38, color=[colr[k] for k in keys], hatch=hat, label=sc.split(" (")[0])
    ax[0].set_yscale("log"); ax[0].set_xticks(x); ax[0].set_xticklabels([SHORT[k] for k in keys], fontsize=5.5); ax[0].set_ylim(0.1, 2.5); ax[0].set_ylabel("latency $T_{\\rm lat}$ (ms), N=4 links"); ax[0].set_title("(a) end-to-end latency"); ax[0].legend(frameon=False, fontsize=6)
    for a, sc, tt in ((ax[1], "software (measured CPU)", "(b) throughput, software decoder"), (ax[2], "dedicated hardware (assumed 10 us)", "(c) throughput, hardware decoder")):
        for k in keys:
            rows = [r for r in C[k]["rows"] if r["scen"] == sc]; a.plot([r["N"] for r in rows], [r["theta_block"] for r in rows], marker="o", ms=3, color=colr[k], label=k.replace("bp_osd0", "BP+OSD"), ls="--" if "mwpm" in k else "-")
        a.set_yscale("log"); a.set_xlabel("number of serial links N"); a.set_xticks(range(1, 11, 3)); a.set_title(tt)
    ax[1].set_ylabel(r"block throughput $\Theta$ (blocks/s)"); ax[2].legend(frameon=False, fontsize=5)
    save(fig, "fig_r7_latency_throughput.png")
    # R8 resources
    fig, ax = plt.subplots(1, 3, figsize=(7.1, 2.6)); N4 = 3
    rows = {k: [r for r in C[k]["rows"] if r["scen"].startswith("dedicated") and r["N"] == 4][0] for k in keys}
    nn = {k: C[k]["n"] for k in keys}; kk = {k: C[k]["k"] for k in keys}
    ax[0].bar(x, [nn[k] for k in keys], .6, color=BL, label="data qubits n"); ax[0].bar(x, [nn[k] - kk[k] for k in keys], .6, bottom=[nn[k] for k in keys], color=OR, label="ancillas n-k"); ax[0].bar(x, [8] * len(keys), .6, bottom=[2 * nn[k] - kk[k] for k in keys], color=GR, label="network 2N")
    ax[0].set_xticks(x); ax[0].set_xticklabels([k.split(" [")[0].replace("Toric ", "T ") + ("\nMWPM" if "mwpm" in k else "") for k in keys], fontsize=5.5); ax[0].set_ylabel(r"physical qubits $C_{\rm phys}$"); ax[0].set_title("(a) resource cost"); ax[0].legend(frameon=False, fontsize=6)
    ax[1].bar(x, [rows[k]["C_phys"] / kk[k] for k in keys], .6, color=[colr[k] for k in keys]); ax[1].set_yscale("log"); ax[1].set_xticks(x); ax[1].set_xticklabels([k.split(" [")[0].replace("Toric ", "T ") + ("\nMWPM" if "mwpm" in k else "") for k in keys], fontsize=5.5); ax[1].set_ylabel(r"$C_{\rm phys}/k$"); ax[1].set_title("(b) cost per logical qubit")
    ax[2].bar(x - .2, [rows[k]["theta_block"] / (rows[k]["C_phys"] / 1000) for k in keys], .38, color=[colr[k] for k in keys], hatch="//", label="one logical qubit per event"); ax[2].bar(x + .2, [rows[k]["theta_per_1000q"] for k in keys], .38, color=[colr[k] for k in keys], label="bulk: k qubits per event"); ax[2].legend(frameon=False, fontsize=5.5); ax[2].set_yscale("log"); ax[2].set_xticks(x); ax[2].set_xticklabels([k.split(" [")[0].replace("Toric ", "T ") + ("\nMWPM" if "mwpm" in k else "") for k in keys], fontsize=5.5); ax[2].set_ylabel("logical-qubit throughput per $10^3$ phys. qubits (1/s)"); ax[2].set_title("(c) efficiency, hardware decoder", fontsize=8)
    save(fig, "fig_r8_resources.png")
    # R9 network success
    cfg = net["cfg"]; fig, ax = plt.subplots(1, 3, figsize=(7.1, 2.6))
    Ns = np.arange(1, 11); ps = net["p_succ_link"]
    ax[0].semilogy(Ns, ps ** Ns, "-", color=BL, label="analytic"); ax[0].semilogy([int(k) for k in net["mc"]], [v["mc"] for v in net["mc"].values()], "o", ms=4, color=RD, label=f"Monte Carlo ($10^6$ trials)")
    ax[0].set_xlabel("number of serial links N"); ax[0].set_ylabel(r"end-to-end success $P_{\rm end}$"); ax[0].set_title("(a) entanglement success"); ax[0].legend(frameon=False)
    for al, c in ((0.15, GR), (0.2, BL), (0.3, RD)):
        Dk = np.linspace(1, 50, 100); ax[1].semilogy(Dk, (10 ** (-al * Dk / 10) * (1 - cfg["p_op"])) ** 4, color=c, label=fr"$\alpha$={al} dB/km")
    ax[1].set_xlabel("link length D (km), N=4"); ax[1].set_ylabel(r"$P_{\rm end}$"); ax[1].set_title("(b) loss sweep"); ax[1].legend(frameon=False)
    bk = [k for k in ("Toric L=23 [mwpm]", "QT-1080 [bp_osd0]", "Toric L=31 [mwpm]", "QT-1920 [bp_osd0]", "QT-3024 [bp_osd0]") if k in C]
    ax[2].bar(np.arange(len(bk)) - .2, [C[k]["PL"] for k in bk], .38, color=[colr[k] for k in bk], label=r"$P_{\rm L}$ ($p=0.005$)"); ax[2].bar(np.arange(len(bk)) + .2, [1 - ps ** 4] * len(bk), .38, color=GY, label=r"$1-P_{\rm end}$ (N=4, 10 km)")
    ax[2].set_yscale("log"); ax[2].set_xticks(range(len(bk))); ax[2].set_xticklabels([k.split(" [")[0].replace("Toric ", "T ") for k in bk], fontsize=6); ax[2].set_title("(c) loss vs logical failure"); ax[2].legend(frameon=False, fontsize=6)
    save(fig, "fig_r9_network_success.png")
print("figures done")
