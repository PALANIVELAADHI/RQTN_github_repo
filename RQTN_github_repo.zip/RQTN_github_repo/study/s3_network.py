"""S3: network layer (Sec. V of the paper): loss, entanglement success, latency, throughput, resource cost.
All code-dependent inputs (P_L, decoder time, n, k, ancillas) come from S1/S2; channel/timing constants are stated assumptions."""
from common import *
cfg = dict(alpha_dB_per_km=0.2, D_link_km=10.0, v_km_per_s=2.0e5, p_op=0.005, t_gate_s=1e-7, t_op_s=1e-6,
           hw_decode_s=1e-5, n_links=list(range(1, 11)), n_mc=1_000_000)
par = load("params.json"); ler = load("ler.json")
name2 = {}
for r in par["toric"]: name2[r["name"]] = dict(n=r["n"], k=r["k"], row=r["row_wt"], d=r["d"])
for r in par["tanner_selected"]: name2[r["name"]] = dict(n=r["n"], k=r["k"], row=r["row_wt"], d=r["d_best"])
def eta(D): return 10 ** (-cfg["alpha_dB_per_km"] * D / 10.0)
def p_succ(): return eta(cfg["D_link_km"]) * (1 - cfg["p_op"])
def pl_at(code, dec, p):
    pts = ler[code]["dec"][dec]; pts = sorted(pts, key=lambda r: r["p"])
    for r in pts:
        if abs(r["p"] - p) < 1e-12: return r["ler"], r["lo"], r["hi"], r["sec_per_shot"]
    raise KeyError((code, dec, p))
out = dict(cfg=cfg, p_succ_link=p_succ(), codes={}, mc={})
rng = np.random.default_rng(2026)
for N in cfg["n_links"]:                                  # Monte-Carlo check of P_end (Eq. P_end)
    analytic = p_succ() ** N; ok = (rng.random((cfg["n_mc"], N)) < p_succ()).all(axis=1).mean()
    out["mc"][N] = dict(analytic=analytic, mc=float(ok), n_mc=cfg["n_mc"])
for code, dec in (("Toric L=23", "mwpm"), ("Toric L=23", "bp_osd0"), ("QT-1080", "bp_osd0"), ("Toric L=31", "mwpm"), ("Toric L=31", "bp_osd0"), ("QT-1920", "bp_osd0"), ("QT-3024", "bp_osd0"), ("Toric L=12", "mwpm"), ("Toric L=8", "mwpm")):
    if code not in ler or dec not in ler[code]["dec"]: continue
    c = name2[code]; PL, lo, hi, tdec = pl_at(code, dec, cfg["p_op"])
    rows = []
    for N in cfg["n_links"]:
        P_end = p_succ() ** N; T_prop = N * cfg["D_link_km"] / cfg["v_km_per_s"]; T_syn = 2 * c["row"] * cfg["t_gate_s"]
        for scen, T_dec in (("software (measured CPU)", tdec), ("dedicated hardware (assumed 10 us)", cfg["hw_decode_s"])):
            T = T_prop + cfg["t_op_s"] + T_syn + T_dec; theta = P_end * (1 - PL) / T
            C = c["n"] + (c["n"] - c["k"]) + 2 * N
            rows.append(dict(N=N, scen=scen, P_end=P_end, T_prop=T_prop, T_op=cfg["t_op_s"], T_syn=T_syn, T_dec=T_dec, T_lat=T, theta_block=theta, theta_logical=c["k"] * theta, C_phys=C, theta_per_1000q=c["k"] * theta / (C / 1000)))
    out["codes"][f"{code} [{dec}]"] = dict(code=code, dec=dec, n=c["n"], k=c["k"], PL=PL, PL_lo=lo, PL_hi=hi, t_dec_s=tdec, rows=rows)
save("network.json", out)
print({k: (round(v["PL"], 5), round(v["t_dec_s"] * 1e3, 3)) for k, v in out["codes"].items()})
