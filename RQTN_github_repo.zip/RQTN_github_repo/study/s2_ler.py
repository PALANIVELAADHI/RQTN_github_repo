"""S2: logical-error sweeps (X noise, code capacity). Toric: MWPM, BP+OSD-0, greedy. Tanner: BP+OSD-0, greedy."""
from common import *
from decoders_extra import greedy_decode, run_generic
from qtanner.gf2 import logical_operators
import pymatching, os
PS = [0.001, 0.002, 0.005, 0.01, 0.02, 0.03]
SH_OSD = {0.001: 20000, 0.002: 20000, 0.005: 10000, 0.01: 3000, 0.02: 800, 0.03: 300}
SH_GR = {0.001: 3000, 0.002: 3000, 0.005: 3000, 0.01: 2000, 0.02: 500, 0.03: 300}
out = load("ler.json") if os.path.exists(os.path.join(DATA, "ler.json")) else {}

def put(code, dec, rec, n, k):
    out.setdefault(code, {"n": n, "k": k, "dec": {}}); lo, hi = wilson(rec["fails"], rec["shots"])
    rec.update(ler=rec["fails"] / rec["shots"], lo=lo, hi=hi); out[code]["dec"].setdefault(dec, []).append(rec); save("ler.json", out)

def have(code, dec, p): return code in out and any(abs(r["p"] - p) < 1e-12 for r in out[code]["dec"].get(dec, []))

codes = []
for L in (6, 8, 12, 23, 31):
    HX, HZ = toric_code(L); Lz, _ = logical_operators(HX, HZ); codes.append((f"Toric L={L}", HZ, Lz, 2, HX))
for name in ("QT-1080", "QT-1920", "QT-3024"):
    Q = make_code(**CATALOG[name]); Lx, Lz = Q.logicals(); codes.append((name, Q.Hz, Lz, int(Lx.shape[0]), Q.Hx))
for name, Hz, Lz, k, _ in codes:
    n = Hz.shape[1]; Ht = sp.csr_matrix(Hz.T) if False else Hz.T.tocsr()
    istoric = name.startswith("Toric")
    for p in PS:
        rng = np.random.default_rng(abs(hash((name, p))) % (2**31))
        if not have(name, "bp_osd0", p):
            dec = make_decoder(Hz, p, "osd_0"); r = run_generic(Hz, Lz, p, SH_OSD[p] if not (istoric and n < 400) else 20000, rng, lambda s: dec.decode(s)); put(name, "bp_osd0", r, n, k); print(name, "osd0", p, r["fails"], r["shots"], round(r["sec_per_shot"] * 1e3, 2), "ms", flush=True)
        if not have(name, "greedy", p):
            r = run_generic(Hz, Lz, p, SH_GR[p], rng, lambda s: greedy_decode(Ht, s)); put(name, "greedy", r, n, k); print(name, "greedy", p, r["fails"], r["shots"], flush=True)
        if istoric and not have(name, "mwpm", p):
            m = pymatching.Matching(Hz); shots = 100000; fails = 0; ch = 20000
            for _ in range(shots // ch):
                E = (rng.random((ch, n)) < p).astype(np.uint8); S = (np.asarray((Hz @ E.T).T) % 2).astype(np.uint8)
                C = m.decode_batch(S); R = E ^ C; fails += int(((R @ Lz.T.toarray()) % 2).any(axis=1).sum())
            ts = np.random.default_rng(1); E1 = (ts.random((2000, n)) < p).astype(np.uint8); import time; t0 = time.perf_counter()
            for e in E1: m.decode((Hz @ e) % 2)
            put(name, "mwpm", dict(p=p, shots=shots, fails=fails, sec_per_shot=(time.perf_counter() - t0) / 2000), n, k); print(name, "mwpm", p, fails, flush=True)
