"""S1: code parameters, check weights, spectral diagnostic Delta_spec = lambda_min^+ (HX^T HX + HZ^T HZ), Cayley spectral ratios."""
from common import *
from qtanner.gf2 import gf2_rank
import scipy.sparse as sp

def delta_spec(HX, HZ, tol=1e-8):
    M = (HX.T @ HX + HZ.T @ HZ).toarray().astype(float)
    ev = np.linalg.eigvalsh(M)
    nz = ev[ev > tol]
    return float(nz.min()) if len(nz) else 0.0, int((ev <= tol).sum()), float(ev.max())

out = {"toric": [], "tanner_selected": [], "tanner_unselected": []}
for L in (4, 5, 6, 8, 10, 12, 16, 23, 31):
    HX, HZ = toric_code(L); n = HX.shape[1]
    ds, nz, lmax = delta_spec(HX, HZ)
    out["toric"].append(dict(name=f"Toric L={L}", L=L, n=n, k=2, d=L, rate=2 / n, row_wt=int(np.diff(HX.indptr).max()), col_wt=int(np.diff(HX.tocsc().indptr).max()), delta_spec=ds, nullity=nz, lam_max=lmax, d_status="exact"))
    print("toric", L, n, ds, flush=True)
prior = load("prior_e21_greedy_all.json"); ipall = load("prior_e14_ip_all.json")
best = {"QT-1080": (12, 12), "QT-1920": (8, 30), "QT-3024": (8, 12)}      # best-found IP weights (X,Z); see paper Sec. on distance
for name in ("QT-1080", "QT-1920", "QT-3024"):
    Q = make_code(**CATALOG[name]); par = Q.parameters(); sp_ = spectral_info(Q)
    ds, nz, lmax = delta_spec(Q.Hx, Q.Hz)
    out["tanner_selected"].append(dict(name=name, n=Q.n, k=par["k"], rate=par["rate"], row_wt=max(par["max_row_weight_x"], par["max_row_weight_z"]), col_wt=max(par["max_col_weight_x"], par["max_col_weight_z"]),
        delta_spec=ds, nullity=nz, lam_max=lmax, rhoA=sp_["A"]["ratio"], rhoB=sp_["B"]["ratio"], ramanujan=bool(max(sp_["A"]["ratio"], sp_["B"]["ratio"]) <= 1),
        d_best_X=best[name][0], d_best_Z=best[name][1], d_best=min(best[name]), greedy=[prior[name]["dx_all"], prior[name]["dz_all"]], d_status="best-found upper bound (integer program)", meta=Q.meta))
    print(name, out["tanner_selected"][-1]["delta_spec"], out["tanner_selected"][-1]["ramanujan"], flush=True)
for fam, (pg, d, kA, kB), seeds in (("F1", (5, 6, 4, 2), range(300, 310)), ("F3", (7, 6, 4, 2), range(300, 303))):
    for seed in seeds:
        Q = make_code(pg, d, kA, kB, seed); par = Q.parameters(); sp_ = spectral_info(Q); ds, nz, lmax = delta_spec(Q.Hx, Q.Hz)
        out["tanner_unselected"].append(dict(name=f"{fam}-{seed}", family=fam, n=Q.n, k=par["k"], rate=par["rate"], delta_spec=ds, rhoA=sp_["A"]["ratio"], rhoB=sp_["B"]["ratio"], ramanujan=bool(max(sp_["A"]["ratio"], sp_["B"]["ratio"]) <= 1)))
        print(fam, seed, ds, flush=True)
save("params.json", out)
