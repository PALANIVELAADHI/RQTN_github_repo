"""Shared helpers for the experiments."""
import json, os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np
from ldpc import BpOsdDecoder, BpDecoder
from qtanner import (PSL2, conjugacy_classes, random_local_code,
                     QuantumTannerCode, cayley_spectrum)
from qtanner.spectral import nontrivial_radius, ramanujan_bound

DATA = os.path.join(os.path.dirname(__file__), "..", "data")
FIG = os.path.join(os.path.dirname(__file__), "..", "figures")
_G = {}


def group(p):
    if p not in _G:
        _G[p] = PSL2(p)
    return _G[p]


def generates(G, S):
    """True iff the symmetric set S generates G (Cayley graph connected)."""
    seen = np.zeros(G.order, dtype=bool); seen[G.identity] = True
    frontier = np.array([G.identity])
    S = np.asarray(S)
    while len(frontier):
        nxt = np.unique(G.mul[S[:, None], frontier[None, :]])
        nxt = nxt[~seen[nxt]]
        seen[nxt] = True; frontier = nxt
    return bool(seen.all())


def random_AB(G, delta, rng):
    """Random inverse-closed A,B of size delta with disjoint conjugacy classes."""
    cls = conjugacy_classes(G)
    ncls = cls.max() + 1
    for _ in range(5000):
        side = rng.integers(0, 2, size=ncls)
        inA = np.where(side[cls] == 0)[0]; inB = np.where(side[cls] == 1)[0]
        if len(inA) < delta + 2 or len(inB) < delta + 2:
            continue
        try:
            A = G.random_symmetric_set(delta, rng, forbidden=frozenset(inB.tolist()))
            B = G.random_symmetric_set(delta, rng, forbidden=frozenset(inA.tolist()))
            if generates(G, A) and generates(G, B):
                return A, B
        except RuntimeError:
            continue
    raise RuntimeError("random_AB failed")


def best_local_code(n, k, rng, trials=60):
    best, key = None, None
    for _ in range(trials):
        C = random_local_code(n, k, rng, 1, 1)
        kk = (min(C.d, C.d_perp), C.d + C.d_perp)
        if key is None or kk > key:
            best, key = C, kk
    return best


def make_code(pg, delta, kA, kB, seed):
    rng = np.random.default_rng(seed)
    G = group(pg)
    A, B = random_AB(G, delta, rng)
    CA = best_local_code(delta, kA, rng)
    CB = best_local_code(delta, kB, rng)
    Q = QuantumTannerCode(G, A, B, CA, CB)
    Q.meta = dict(p=pg, delta=delta, kA=kA, kB=kB, seed=seed,
                  A=[int(x) for x in A], B=[int(x) for x in B],
                  CA=str(CA), CB=str(CB))
    return Q


def spectral_info(Q):
    G = Q.G
    out = {}
    for name, S in (("A", Q.A), ("B", Q.B)):
        ev = cayley_spectrum(G, S)
        d = len(S)
        out[name] = dict(radius=nontrivial_radius(ev, d), delta=d,
                         bound=float(ramanujan_bound(d)))
        out[name]["ratio"] = out[name]["radius"] / out[name]["bound"]
    return out


def wilson(f, n, z=1.96):
    if n == 0:
        return (0.0, 1.0)
    p = f / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, c - h), min(1.0, c + h))


def make_decoder(H, p, kind="osd_cs", max_iter=60, ms=0.625):
    if kind == "bp":
        return BpDecoder(H, error_rate=p, max_iter=max_iter, bp_method="minimum_sum",
                         ms_scaling_factor=ms)
    return BpOsdDecoder(H, error_rate=p, max_iter=max_iter, bp_method="minimum_sum",
                        ms_scaling_factor=ms,
                        osd_method="osd_cs" if kind == "osd_cs" else "osd_0",
                        osd_order=7 if kind == "osd_cs" else 0)


def run_shots(Hdet, Ldet, p, shots, rng, kind="osd_cs", fixed_weight=None,
              max_iter=60, min_resid=None, ms=0.625):
    """Code-capacity noise on one Pauli type. Returns dict."""
    n = Hdet.shape[1]
    dec = make_decoder(Hdet, p if fixed_weight is None else max(fixed_weight / n, 1e-3),
                       kind, max_iter, ms)
    fails, t0 = 0, time.time()
    for _ in range(shots):
        if fixed_weight is None:
            e = (rng.random(n) < p).astype(np.uint8)
        else:
            e = np.zeros(n, dtype=np.uint8)
            e[rng.choice(n, fixed_weight, replace=False)] = 1
        s = (Hdet @ e) % 2
        c = np.asarray(dec.decode(s), dtype=np.uint8)
        r = e ^ c
        bad = bool(((Hdet @ r) % 2).any()) or bool(((Ldet @ r) % 2).any())
        if bad:
            fails += 1
            if min_resid is not None and not ((Hdet @ r) % 2).any():
                min_resid.append(int(r.sum()))
    dt = (time.time() - t0) / shots
    lo, hi = wilson(fails, shots)
    return dict(p=p, shots=shots, fails=fails, ler=fails / shots, lo=lo, hi=hi, sec_per_shot=dt)


def save(name, obj):
    os.makedirs(DATA, exist_ok=True)
    with open(os.path.join(DATA, name), "w") as f:
        json.dump(obj, f, indent=1)


def load(name):
    with open(os.path.join(DATA, name)) as f:
        return json.load(f)


# Catalogue of code instances used throughout the paper
CATALOG = {
    "QT-1080": dict(pg=5, delta=6, kA=4, kB=2, seed=5),
    "QT-1920": dict(pg=5, delta=8, kA=5, kB=3, seed=8),
    "QT-3000": dict(pg=5, delta=10, kA=7, kB=3, seed=7),
    "QT-3024": dict(pg=7, delta=6, kA=4, kB=2, seed=4),
    "QT-5376": dict(pg=7, delta=8, kA=5, kB=3, seed=15),
}


def toric_code(L):
    """Toric code as hypergraph product of two length-L ring repetition codes."""
    import scipy.sparse as sp
    I = sp.identity(L, dtype=np.uint8, format="csr")
    H = sp.csr_matrix(np.eye(L, dtype=np.uint8) ^ np.roll(np.eye(L, dtype=np.uint8), 1, axis=1))
    Hx = sp.hstack([sp.kron(H, I), sp.kron(I, H.T)]).tocsr()
    Hz = sp.hstack([sp.kron(I, H), sp.kron(H.T, I)]).tocsr()
    Hx.data %= 2; Hz.data %= 2
    return Hx, Hz


def random_AB_bip(G, delta, rng):
    """A,B inverse-closed subsets of the odd coset of PGL(2,q), in disjoint conjugacy classes, each generating G."""
    cls = conjugacy_classes(G); odd = np.where(G.odd)[0]; ncls = cls.max() + 1
    for _ in range(5000):
        side = rng.integers(0, 2, size=ncls)
        inA = [g for g in odd if side[cls[g]] == 0]; inB = [g for g in odd if side[cls[g]] == 1]
        if len(inA) < delta + 2 or len(inB) < delta + 2: continue
        try:
            A = G.random_symmetric_set_in(delta, rng, inA); B = G.random_symmetric_set_in(delta, rng, inB)
        except RuntimeError:
            continue
        if generates(G, A) and generates(G, B): return A, B
    raise RuntimeError("random_AB_bip failed")
