from common import *
def hill_climb(v, stab_rows, n, rng, rounds=6):
    best = v
    for _ in range(rounds):
        improved = False
        for i in rng.permutation(len(stab_rows)):
            w = best ^ stab_rows[i]
            if bin(w).count("1") < bin(best).count("1"):
                best = w; improved = True
        if not improved:
            break
    return bin(best).count("1")
