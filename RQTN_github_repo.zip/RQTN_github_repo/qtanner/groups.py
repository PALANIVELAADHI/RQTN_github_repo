"""PSL(2,p) with a precomputed multiplication table (NumPy)."""
from __future__ import annotations
import itertools
import numpy as np


class PSL2:
    def __init__(self, p: int):
        self.p = p
        elems = set()
        for a, b, c, d in itertools.product(range(p), repeat=4):
            if (a * d - b * c) % p == 1:
                m = (a, b, c, d)
                elems.add(min(m, tuple((-x) % p for x in m)))
        self.elements = sorted(elems)
        self.order = len(self.elements)
        self.index = {e: i for i, e in enumerate(self.elements)}
        E = np.array(self.elements, dtype=np.int64)
        a, b, c, d = (E[:, i] for i in range(4))
        M = np.stack([(a[:, None]*a[None]+b[:, None]*c[None]) % p,
                      (a[:, None]*b[None]+b[:, None]*d[None]) % p,
                      (c[:, None]*a[None]+d[:, None]*c[None]) % p,
                      (c[:, None]*b[None]+d[:, None]*d[None]) % p], axis=-1)
        Mn = (-M) % p
        w = np.array([p**3, p**2, p, 1], dtype=np.int64)
        kM, kN = (M*w).sum(-1), (Mn*w).sum(-1)
        key = np.minimum(kM, kN)                      # canonical rep = smaller key
        keys = (E*w).sum(-1)
        order = np.argsort(keys)
        self.mul = order[np.searchsorted(keys[order], key)].astype(np.int32)
        self.identity = self.index[min((1, 0, 0, 1), (p-1, 0, 0, p-1))]
        gi, hi = np.where(self.mul == self.identity)
        self.inv = np.empty(self.order, dtype=np.int32)
        self.inv[gi] = hi

    def random_symmetric_set(self, size, rng, forbidden=frozenset()):
        out, tries = set(), 0
        while len(out) < size and tries < 100000:
            tries += 1
            g = int(rng.integers(self.order)); gi = int(self.inv[g])
            if g == self.identity or g in out or g in forbidden or gi in forbidden:
                continue
            need = 1 if gi == g else 2
            if len(out) + need > size:
                continue
            out.update((g, gi))
        if len(out) != size:
            raise RuntimeError("cannot draw symmetric set")
        return sorted(out)


def conjugacy_classes(G: PSL2):
    n = G.order
    cls = -np.ones(n, dtype=np.int32); c = 0
    ar = np.arange(n)
    for g in range(n):
        if cls[g] >= 0:
            continue
        orb = G.mul[G.mul[ar, g], G.inv[ar]]          # x g x^-1
        cls[np.unique(orb)] = c; c += 1
    return cls


class PGL2:
    """PGL(2,q) (q odd prime) with multiplication table; PSL(2,q) is the index-2 subgroup of 'even' elements
    (determinant a square mod q). Used for the bipartite (non-double-cover) quantum Tanner construction."""
    def __init__(self, q: int):
        self.q = q
        inv = np.zeros(q, dtype=np.int64)
        for x in range(1, q):
            inv[x] = pow(x, q - 2, q)
        self._inv = inv
        elems = set()
        for a, b, c, d in itertools.product(range(q), repeat=4):
            if (a * d - b * c) % q:
                elems.add(self._norm1((a, b, c, d)))
        self.elements = sorted(elems); self.order = len(self.elements)
        self.index = {e: i for i, e in enumerate(self.elements)}
        E = np.array(self.elements, dtype=np.int64)
        a, b, c, d = (E[:, i] for i in range(4))
        M = np.stack([(a[:, None]*a[None]+b[:, None]*c[None]) % q, (a[:, None]*b[None]+b[:, None]*d[None]) % q,
                      (c[:, None]*a[None]+d[:, None]*c[None]) % q, (c[:, None]*b[None]+d[:, None]*d[None]) % q], axis=-1)
        first = np.where(M[..., 0] != 0, M[..., 0], np.where(M[..., 1] != 0, M[..., 1], np.where(M[..., 2] != 0, M[..., 2], M[..., 3])))
        M = (M * inv[first][..., None]) % q
        w = np.array([q**3, q**2, q, 1], dtype=np.int64)
        key = (M * w).sum(-1); keys = (E * w).sum(-1); order = np.argsort(keys)
        self.mul = order[np.searchsorted(keys[order], key)].astype(np.int32)
        self.identity = self.index[self._norm1((1, 0, 0, 1))]
        gi, hi = np.where(self.mul == self.identity)
        self.inv = np.empty(self.order, dtype=np.int32); self.inv[gi] = hi
        squares = {(x * x) % q for x in range(1, q)}
        det = (E[:, 0] * E[:, 3] - E[:, 1] * E[:, 2]) % q
        self.odd = np.array([int(x) not in squares for x in det])      # True = not in PSL(2,q)

    def _norm1(self, m):
        for x in m:
            if x % self.q:
                s = int(self._inv[x % self.q]); return tuple((s * y) % self.q for y in m)

    def random_symmetric_set_in(self, size, rng, allowed, forbidden=frozenset()):
        allowed = set(int(x) for x in allowed); out, tries = set(), 0
        al = sorted(allowed)
        while len(out) < size and tries < 100000:
            tries += 1
            g = int(al[int(rng.integers(len(al)))]); gi = int(self.inv[g])
            if g in out or g in forbidden or gi in forbidden or gi not in allowed:
                continue
            need = 1 if gi == g else 2
            if len(out) + need > size: continue
            out.update((g, gi))
        if len(out) != size: raise RuntimeError("cannot draw symmetric set")
        return sorted(out)
