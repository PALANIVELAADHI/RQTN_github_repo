"""GF(2) linear algebra helpers (python-int bitsets + ldpc.mod2)."""
from __future__ import annotations
import numpy as np
import scipy.sparse as sp
import ldpc.mod2 as m2


def rows_as_ints(H):
    H = sp.csr_matrix(H)
    out = []
    for i in range(H.shape[0]):
        v = 0
        for j in H.indices[H.indptr[i]:H.indptr[i + 1]]:
            v |= 1 << int(j)
        out.append(v)
    return out


class XorBasis:
    def __init__(self):
        self.piv = {}

    def reduce(self, v):
        while v:
            h = v.bit_length() - 1
            b = self.piv.get(h)
            if b is None:
                return v
            v ^= b
        return 0

    def add(self, v):
        v = self.reduce(v)
        if v:
            self.piv[v.bit_length() - 1] = v
            return True
        return False


def gf2_rank(H):
    B = XorBasis()
    for v in rows_as_ints(H):
        B.add(v)
    return len(B.piv)


def gf2_kernel(H):
    return sp.csr_matrix(m2.kernel(sp.csr_matrix(H)))


def logical_operators(H_detect_kernel, H_stab):
    """Vectors in ker(H_detect_kernel) independent modulo rowspace(H_stab)."""
    K = gf2_kernel(H_detect_kernel)
    B = XorBasis()
    for v in rows_as_ints(H_stab):
        B.add(v)
    base = len(B.piv)
    kv = rows_as_ints(K)
    keep = []
    for idx, v in enumerate(kv):
        if B.add(v):
            keep.append(idx)
    return K[keep], len(B.piv) - base


def int_to_dense(v, n):
    return np.array([(v >> j) & 1 for j in range(n)], dtype=np.uint8)
