"""Quantum Tanner code on the (bipartite double cover of the) left-right
Cayley complex Cay(G,A) x Cay(G,B).

Squares  : (g,a,b) ~ (agb, a^-1, b^-1)   -> qubits, n = |G||A||B|/2
V0 vertex: (g,0) with view (a,b) -> square (g,a,b)
V1 vertex: (h,1) with view (a,b) -> square (a^-1 h, a, b)
X checks : C_A (x) C_B at every V0 vertex
Z checks : sigma(C_A^perp) (x) C_B^perp at every V1 vertex  (sigma: a->a^-1)
"""
from __future__ import annotations
import numpy as np
import scipy.sparse as sp
from .groups import conjugacy_classes
from .gf2 import gf2_rank, logical_operators


class QuantumTannerCode:
    def __init__(self, G, A, B, CA, CB):
        cls = conjugacy_classes(G)
        if set(cls[A]) & set(cls[B]):
            raise ValueError("A and B share a conjugacy class: degenerate squares")
        self.G, self.A, self.B, self.CA, self.CB = G, np.array(A), np.array(B), CA, CB
        dA, dB, N = len(A), len(B), G.order
        assert CA.n == dA and CB.n == dB
        self.dA, self.dB = dA, dB
        posA = {a: i for i, a in enumerate(A)}; posB = {b: i for i, b in enumerate(B)}
        invA = np.array([posA[int(G.inv[a])] for a in A])
        invB = np.array([posB[int(G.inv[b])] for b in B])
        g = np.arange(N)[:, None, None]
        ai = np.arange(dA)[None, :, None]; bi = np.arange(dB)[None, None, :]
        Aa = self.A[None, :, None]; Bb = self.B[None, None, :]
        ag = G.mul[Aa, g]; agb = G.mul[ag, Bb]
        flat = (g * dA + ai) * dB + bi
        partner = (agb * dA + invA[None, :, None]) * dB + invB[None, None, :]
        canon = np.minimum(flat, partner)
        uniq, comp = np.unique(canon, return_inverse=True)
        comp = comp.reshape(flat.shape)
        self.n = len(uniq)
        assert self.n == N * dA * dB // 2
        self.sq0 = comp                                     # V0 views [g,a,b]
        # V1 view: square (a^-1 h, a, b)
        aInvEl = G.inv[self.A]                              # elements a^-1
        gp = G.mul[aInvEl[None, :, None], np.arange(N)[:, None, None]]
        self.sq1 = comp[gp, ai + 0 * bi, bi + 0 * ai]       # [h,a,b]
        # local generators
        GA, GB = CA.G, CB.G
        Tx = np.kron(GA, GB) % 2                            # (kA kB, dA dB)
        HAs = CA.H[:, invA] % 2                             # sigma applied
        Tz = np.kron(HAs, CB.H) % 2
        self.Hx = self._assemble(Tx, self.sq0)
        self.Hz = self._assemble(Tz, self.sq1)

    def _assemble(self, T, views):
        N = views.shape[0]
        r, c = T.shape
        rows, cols = [], []
        ti, tj = np.nonzero(T)
        for v in range(N):
            cols.append(views[v].reshape(-1)[tj]); rows.append(v * r + ti)
        rows = np.concatenate(rows); cols = np.concatenate(cols)
        H = sp.csr_matrix((np.ones(len(rows), dtype=np.uint8), (rows, cols)),
                          shape=(N * r, self.n))
        H.data %= 2
        return H

    def commutes(self):
        P = (self.Hx @ self.Hz.T).tocsr()
        P.data %= 2
        P.eliminate_zeros()
        return P.nnz == 0

    def parameters(self):
        rx, rz = gf2_rank(self.Hx), gf2_rank(self.Hz)
        return dict(n=self.n, k=self.n - rx - rz, rank_x=rx, rank_z=rz,
                    rate=(self.n - rx - rz) / self.n,
                    max_row_weight_x=int(np.diff(self.Hx.indptr).max()),
                    max_row_weight_z=int(np.diff(self.Hz.indptr).max()),
                    max_col_weight_x=int(np.diff(self.Hx.tocsc().indptr).max()),
                    max_col_weight_z=int(np.diff(self.Hz.tocsc().indptr).max()))

    def logicals(self):
        """Lz detects X errors (ker Hx mod rowspace Hz); Lx detects Z errors."""
        Lz, kz = logical_operators(self.Hx, self.Hz)
        Lx, kx = logical_operators(self.Hz, self.Hx)
        assert kz == kx
        return Lx, Lz
