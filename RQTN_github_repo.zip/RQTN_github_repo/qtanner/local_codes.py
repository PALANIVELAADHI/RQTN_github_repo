"""Small binary local codes C_A, C_B."""
from __future__ import annotations
import itertools
import numpy as np


def _nullspace_dense(G):
    """Basis of {x: G x = 0} over GF(2), G is (r, n) dense uint8."""
    G = G.copy() % 2
    r, n = G.shape
    piv, row = [], 0
    for c in range(n):
        p = None
        for i in range(row, r):
            if G[i, c]:
                p = i; break
        if p is None:
            continue
        G[[row, p]] = G[[p, row]]
        for i in range(r):
            if i != row and G[i, c]:
                G[i] ^= G[row]
        piv.append(c); row += 1
        if row == r:
            break
    free = [c for c in range(n) if c not in piv]
    N = np.zeros((len(free), n), dtype=np.uint8)
    for t, f in enumerate(free):
        N[t, f] = 1
        for i, c in enumerate(piv):
            N[t, c] = G[i, f]
    return N


def min_distance(G):
    k, n = G.shape
    best = n
    for coeffs in itertools.product([0, 1], repeat=k):
        if not any(coeffs):
            continue
        w = int((np.array(coeffs) @ G % 2).sum())
        best = min(best, w)
    return best


class LocalCode:
    def __init__(self, G):
        self.G = np.asarray(G, dtype=np.uint8) % 2
        self.k, self.n = self.G.shape
        self.H = _nullspace_dense(self.G)          # basis of dual code, (n-k, n)
        assert not ((self.G @ self.H.T) % 2).any()
        self.d = min_distance(self.G)
        self.d_perp = min_distance(self.H) if self.H.shape[0] else self.n

    def __repr__(self):
        return f"[{self.n},{self.k},{self.d}] dual [{self.n},{self.n-self.k},{self.d_perp}]"


def random_local_code(n, k, rng, min_d=2, min_dperp=2, tries=20000):
    for _ in range(tries):
        P = rng.integers(0, 2, size=(k, n - k), dtype=np.uint8)
        G = np.concatenate([np.eye(k, dtype=np.uint8), P], axis=1)
        perm = rng.permutation(n)
        C = LocalCode(G[:, perm])
        if C.d >= min_d and C.d_perp >= min_dperp:
            return C
    raise RuntimeError("no suitable local code")
