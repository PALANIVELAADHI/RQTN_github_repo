import numpy as np


def cayley_spectrum(G, S):
    """Eigenvalues (sorted desc) of the left Cayley graph Cay(G,S): g ~ s g."""
    n = G.order
    M = np.zeros((n, n))
    ar = np.arange(n)
    for s in S:
        M[G.mul[s, ar], ar] += 1
    return np.sort(np.linalg.eigvalsh(M))[::-1]


def ramanujan_bound(delta):
    return 2.0 * np.sqrt(delta - 1)


def nontrivial_radius(ev, delta, tol=1e-8):
    """max |lambda| over eigenvalues that are not +-delta."""
    nt = ev[np.abs(np.abs(ev) - delta) > tol]
    return float(np.abs(nt).max()) if len(nt) else 0.0


def is_ramanujan(ev, delta):
    return nontrivial_radius(ev, delta) <= ramanujan_bound(delta) + 1e-9
