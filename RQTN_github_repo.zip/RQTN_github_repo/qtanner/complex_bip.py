"""Bipartite (index-2 subgroup) quantum Tanner code: the standard left-right Cayley complex when G has an
index-2 subgroup G0 and A, B lie outside G0. V0 = G0 (X checks), V1 = G \\ G0 (Z checks), qubits = squares
[(g,a,b)] ~ [(agb,a^-1,b^-1)] with g in G0, so n = |G0||A||B|/2."""
from __future__ import annotations
import numpy as np
import scipy.sparse as sp
from .groups import conjugacy_classes
from .complex import QuantumTannerCode


class QuantumTannerBipartite(QuantumTannerCode):
    def __init__(self, G, A, B, CA, CB):
        odd = G.odd
        if not (odd[A].all() and odd[B].all()):
            raise ValueError("A and B must lie outside the index-2 subgroup")
        cls = conjugacy_classes(G)
        if set(cls[A]) & set(cls[B]):
            raise ValueError("A and B share a conjugacy class")
        self.G, self.A, self.B, self.CA, self.CB = G, np.array(A), np.array(B), CA, CB
        dA, dB = len(A), len(B); self.dA, self.dB = dA, dB
        ev = np.where(~odd)[0]; od = np.where(odd)[0]; M = len(ev)
        posE = -np.ones(G.order, dtype=np.int64); posE[ev] = np.arange(M)
        posA = {a: i for i, a in enumerate(A)}; posB = {b: i for i, b in enumerate(B)}
        invA = np.array([posA[int(G.inv[a])] for a in A]); invB = np.array([posB[int(G.inv[b])] for b in B])
        g = ev[:, None, None]; ai = np.arange(dA)[None, :, None]; bi = np.arange(dB)[None, None, :]
        ag = G.mul[self.A[None, :, None], g]; agb = G.mul[ag, self.B[None, None, :]]
        flat = (np.arange(M)[:, None, None] * dA + ai) * dB + bi
        partner = (posE[agb] * dA + invA[None, :, None]) * dB + invB[None, None, :]
        uniq, comp = np.unique(np.minimum(flat, partner), return_inverse=True)
        comp = comp.reshape(flat.shape); self.n = len(uniq)
        assert self.n == M * dA * dB // 2
        self.sq0 = comp
        aInvEl = G.inv[self.A]
        gp = G.mul[aInvEl[None, :, None], od[:, None, None]]                     # a^-1 h, even
        self.sq1 = comp[posE[gp], ai + 0 * bi, bi + 0 * ai]
        Tx = np.kron(CA.G, CB.G) % 2; Tz = np.kron(CA.H[:, invA] % 2, CB.H) % 2
        self.Hx = self._assemble(Tx, self.sq0); self.Hz = self._assemble(Tz, self.sq1)
