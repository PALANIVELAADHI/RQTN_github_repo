Code: MIT (see LICENSE). Data, figures and manuscript text: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/
