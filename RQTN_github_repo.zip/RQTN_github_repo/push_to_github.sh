#!/bin/bash
# usage: ./push_to_github.sh <github-username>
set -e
U=${1:?usage: ./push_to_github.sh <github-username>}
sed -i "s/YOUR-USERNAME/$U/g" paper/references.bib paper/make_paper.py paper/head_template.tex 2>/dev/null || true
git init -q; git add .; git commit -qm "Ramanujan quantum Tanner network benchmark"; git branch -M main
git remote add origin https://github.com/$U/ramanujan-quantum-tanner-network.git
echo "Create the empty repository 'ramanujan-quantum-tanner-network' on GitHub, then run: git push -u origin main"
